create view MVV as
select child.id child, parent.id parent from child join parent on parent.id = child.parent_id
