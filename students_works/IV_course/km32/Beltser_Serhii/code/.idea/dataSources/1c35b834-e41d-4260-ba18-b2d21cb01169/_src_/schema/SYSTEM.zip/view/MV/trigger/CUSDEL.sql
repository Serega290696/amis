create trigger CUSDEL
	instead of delete
	on MV
	for each row
declare 
    pragma AUTONOMOUS_TRANSACTION;
BEGIN 
    DBMS_OUTPUT.PUT_LINE('Here'); 
END;