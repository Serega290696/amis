create view MV as
select "TITLE","AGE" from os
