create view SHOWVENDANDPROD as
SELECT v.vend_id vend_id, pr.prod_id prod_id
  FROM Vendors v LEFT JOIN Products pr ON v.vend_id = pr.vend_id 
  LEFT JOIN OrderItems o ON pr.prod_id = o.prod_id
  GROUP BY v.vend_id, pr.prod_id
  HAVING SUM(quantity * item_price) > 500
